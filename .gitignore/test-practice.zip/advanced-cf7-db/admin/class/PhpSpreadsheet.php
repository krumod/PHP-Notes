<?php

require(plugin_dir_path(__FILE__) . 'vendor/autoload.php');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

function download_file($form_title,$arrHeader,$data_sorted,$fields){

	$spreadsheet = new Spreadsheet();

	//First we will set header in excel file
	$col = 1;
	$row = 1;
	foreach($arrHeader as $colName){
		$spreadsheet->getActiveSheet()->setCellValueByColumnAndRow($col, $row, $colName);
		$col++;
	}

	$row = 2;
	foreach ($data_sorted as $k => $v){
		//Define column index here
		$col=1;
		//Get column order wise value here
		foreach ($fields as $k2 => $v2){
			$colVal = (isset($v[$k2]) ? html_entity_decode($v[$k2]) : '');
			// $cell = $xls->getCellNo($row, $col);
			// $xls->setActiveSheetIndex(0)->setCellValue($cell,$colVal);
			$spreadsheet->getActiveSheet()->setCellValueByColumnAndRow($col, $row, $colVal);
			$col++;
		}
		//Consider new row for each entry here
		$row++;
	}

	$spreadsheet->setActiveSheetIndex(0);

	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	header('Content-Disposition: attachment;filename='.$form_title.'.xlsx');
	$writer = new Xlsx($spreadsheet);
	ob_end_clean();
	$writer->save('php://output');
}

// function download_file(){
// 	require(plugin_dir_path(__FILE__) . 'vendor/autoload.php');
// 	//include plugin_dir_path(__FILE__).'\PhpOffice\PhpSpreadsheet\src\Spreadsheet';

// 	use PhpOffice\PhpSpreadsheet\Spreadsheet;
// 	use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// 	//$spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
// 	$spreadsheet = new Spreadsheet();
// 	$sheet = $spreadsheet->getActiveSheet();
// 	$sheet->setCellValue('A1', 'Hello World !');
// 	$sheet->setCellValue('A1', 'First Name');
// 	$sheet->setCellValue('B1', 'Last Name');
// 	$sheet->setCellValue('C1', 'Created At');
// 	$sheet->setCellValue('D1', 'Updated At');

// 	$sheet->setCellValue('A2', 'Krunal');
// 	$sheet->setCellValue('B2', 'Modi');
// 	$sheet->setCellValue('C2', 'Created At');
// 	$sheet->setCellValue('D2', 'Updated At');

// 	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
// 	header('Content-Disposition: attachment;filename="myfile.xlsx"');
// 	$writer = new Xlsx($spreadsheet);
// 	ob_end_clean();
// 	$writer->save('php://output');
// }
// require(plugin_dir_path(__FILE__) . 'vendor/autoload.php');
// //include plugin_dir_path(__FILE__).'\PhpOffice\PhpSpreadsheet\src\Spreadsheet';

// use PhpOffice\PhpSpreadsheet\Spreadsheet;
// use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// //$spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
// $spreadsheet = new Spreadsheet();
// $sheet = $spreadsheet->getActiveSheet();
// $sheet->setCellValue('A1', 'Hello World !');
// $sheet->setCellValue('A1', 'First Name');
// $sheet->setCellValue('B1', 'Last Name');
// $sheet->setCellValue('C1', 'Created At');
// $sheet->setCellValue('D1', 'Updated At');

// $sheet->setCellValue('A2', 'Krunal');
// $sheet->setCellValue('B2', 'Modi');
// $sheet->setCellValue('C2', 'Created At');
// $sheet->setCellValue('D2', 'Updated At');

// header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
// header('Content-Disposition: attachment;filename="myfile.xlsx"');
// $writer = new Xlsx($spreadsheet);
// ob_end_clean();
// $writer->save('php://output');

?>

